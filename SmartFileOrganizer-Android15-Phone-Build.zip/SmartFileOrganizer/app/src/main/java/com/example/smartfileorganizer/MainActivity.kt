package com.example.smartfileorganizer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B1020)
private val SurfaceDark = Color(0xFF151D30)
private val Accent = Color(0xFF8B9CFF)
private val Muted = Color(0xFF9AA7BD)

class MainActivity : ComponentActivity() {
    private var selectedTree by mutableStateOf<Uri?>(null)
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            selectedTree = uri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, background = Bg, surface = SurfaceDark,
                onBackground = Color.White, onSurface = Color.White
            )) {
                OrganizerScreen(
                    rootUri = selectedTree,
                    onChooseFolder = { folderPicker.launch(null) },
                    resolver = contentResolver
                )
            }
        }
    }
}

private data class FileRow(val file: DocumentFile, val name: String, val size: Long, val mime: String?)

@Composable
private fun OrganizerScreen(rootUri: Uri?, onChooseFolder: () -> Unit, resolver: android.content.ContentResolver) {
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<FileRow>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Choose a folder to start organizing") }
    var tab by remember { mutableStateOf("All") }

    fun refresh() {
        val uri = rootUri ?: return
        busy = true
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(resolver.contextOrNull(), uri)
                root?.listFiles()?.filter { it.isFile }?.map {
                    FileRow(it, it.name ?: "Unnamed file", it.length(), it.type)
                }?.sortedBy { it.name.lowercase(Locale.getDefault()) } ?: emptyList()
            }
            files = result
            busy = false
            message = "${result.size} files found"
        }
    }

    LaunchedEffect(rootUri) { refresh() }

    val visible = files.filter { row ->
        val matchesSearch = row.name.contains(search, ignoreCase = true)
        val category = categoryFor(row.name)
        matchesSearch && (tab == "All" || category == tab)
    }
    val totalBytes = files.sumOf { it.size }
    val categories = listOf("All", "Images", "Videos", "Documents", "Audio", "Archives", "Other")

    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SMART FILE", color = Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Text("Organizer", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            }
            Surface(color = SurfaceDark, shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.FolderOpen, null, tint = Accent, modifier = Modifier.padding(14.dp).size(25.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("STORAGE OVERVIEW", color = Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(if (rootUri == null) "No folder selected" else formatBytes(totalBytes),
                    style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(if (rootUri == null) "Grant access to a folder on your device" else "${files.size} files in selected folder",
                    color = Muted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(14.dp))
                Button(onClick = onChooseFolder, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF10152A))) {
                    Icon(Icons.Default.FolderOpen, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (rootUri == null) "Choose storage folder" else "Change folder", fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = search, onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search files…", color = Muted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) }, singleLine = true,
            shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent, unfocusedBorderColor = SurfaceDark,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                cursorColor = Accent))
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Your files", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { refresh() }, enabled = rootUri != null && !busy) {
                Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp)); Text("Refresh")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
            categories.take(4).forEach { c ->
                FilterChip(selected = tab == c, onClick = { tab = c }, label = { Text(c, maxLines = 1) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            categories.drop(4).forEach { c ->
                FilterChip(selected = tab == c, onClick = { tab = c }, label = { Text(c) })
            }
        }
        Spacer(Modifier.height(8.dp))
        if (busy) {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
        } else if (rootUri == null) {
            EmptyState("Folder access needed", "Choose a folder above. Android will ask you to approve access.")
        } else if (visible.isEmpty()) {
            EmptyState("Nothing here yet", "No files match this view.")
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(visible, key = { it.file.uri.toString() }) { row ->
                    FileItem(row)
                }
            }
        }
        Text(message, color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp))
        if (rootUri != null) {
            Button(onClick = {
                busy = true
                scope.launch {
                    val outcome = withContext(Dispatchers.IO) { organizeFolder(resolver, rootUri) }
                    refresh()
                    message = outcome
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF10152A))) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text("Organize files automatically", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun FileItem(row: FileRow) {
    val category = categoryFor(row.name)
    val icon = when (category) {
        "Images" -> Icons.Default.Image
        "Videos" -> Icons.Default.Movie
        "Audio" -> Icons.Default.MusicNote
        "Documents" -> Icons.Default.Description
        "Archives" -> Icons.Default.FolderZip
        else -> Icons.Default.InsertDriveFile
    }
    Row(Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(14.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(row.name, color = Color.White, maxLines = 1, fontWeight = FontWeight.Medium)
            Text("$category • ${formatBytes(row.size)}", color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.FolderOpen, null, tint = Muted, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(body, color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

private fun categoryFor(name: String): String {
    return when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
        "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp", "svg" -> "Images"
        "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "Videos"
        "mp3", "wav", "aac", "flac", "ogg", "m4a" -> "Audio"
        "pdf", "doc", "docx", "txt", "rtf", "xls", "xlsx", "ppt", "pptx", "csv" -> "Documents"
        "zip", "rar", "7z", "tar", "gz" -> "Archives"
        else -> "Other"
    }
}

private fun organizeFolder(resolver: android.content.ContentResolver, treeUri: Uri): String {
    val root = DocumentFile.fromTreeUri(AppContextHolder.context, treeUri) ?: return "Could not open folder"
    val folders = listOf("Images", "Videos", "Documents", "Audio", "Archives", "Other")
    val destinations = folders.associateWith { name ->
        root.findFile(name)?.takeIf { it.isDirectory } ?: root.createDirectory(name)
    }
    var moved = 0
    var skipped = 0
    root.listFiles().filter { it.isFile }.forEach { source ->
        val name = source.name ?: run { skipped++; return@forEach }
        val destination = destinations[categoryFor(name)]
        if (destination == null || destination.findFile(name) != null) { skipped++; return@forEach }
        try {
            val mime = source.type ?: "application/octet-stream"
            val target = destination.createFile(mime, name)
            if (target == null) { skipped++; return@forEach }
            resolver.openInputStream(source.uri)?.use { input ->
                resolver.openOutputStream(target.uri)?.use { output -> input.copyTo(output) }
            } ?: run { target.delete(); skipped++; return@forEach }
            if (source.delete()) moved++ else skipped++
        } catch (_: Exception) { skipped++ }
    }
    return "Organized $moved files • $skipped skipped"
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = -1
    do { value /= 1024.0; index++ } while (value >= 1024 && index < units.lastIndex)
    return String.format(Locale.getDefault(), "%.1f %s", value, units[index])
}

/* Application context is initialized by the Activity before composables run. */
private object AppContextHolder { lateinit var context: android.content.Context }
private fun android.content.ContentResolver.contextOrNull(): android.content.Context = AppContextHolder.context
