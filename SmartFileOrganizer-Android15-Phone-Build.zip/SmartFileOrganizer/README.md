# Smart File Organizer (Android 15)

A dark-themed Android file organizer starter app designed for modern Android devices, including Snapdragon 888 hardware.

## Features
- Folder access through Android's Storage Access Framework (no broad storage permission)
- Browse files in the selected folder
- Search by filename and filter by category
- Show total selected-folder file size
- Automatically sort files into Images, Videos, Documents, Audio, Archives, and Other
- Dark UI, lightweight local processing, no ads, no analytics, and no network permission

## Build the APK
This environment could not compile an APK because the Android SDK and Gradle build tools are not installed. The complete Android Studio project is included.

1. Install Android Studio (current stable) on a computer.
2. Open this `SmartFileOrganizer` folder.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, use **Build > Generate Signed Bundle / APK** and create a signing key.

## Device compatibility
- `minSdk 26`, `targetSdk 35` (Android 15)
- Java 17 / Kotlin / Jetpack Compose
- Snapdragon 888 is more than capable; the app performs file operations locally and does not require GPU acceleration.

## Important storage behavior
Android 11+ restricts access to protected locations. Choose a folder using the system picker and approve access. The app only organizes files directly inside the selected folder; it does not recursively scan protected app folders. The organize action moves files by copying them into category folders and deleting the original after a successful copy. Back up important files before bulk organization.

## Build from an Android phone (cloud build)

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. In your phone browser, sign in to GitHub and create a new repository (public or private).
2. Upload the contents of this project folder to the repository, preserving folder paths. Include the hidden `.github` folder and its workflow file.
3. Open the repository's **Actions** tab and select **Build Android APK**. Tap **Run workflow** if it has not started automatically.
4. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `SmartFileOrganizer-debug-apk`.
5. Extract the downloaded artifact ZIP. Tap `app-debug.apk` to install it. If Android asks, allow your browser or Files app to install unknown apps, then retry installation.

Only install APKs you built yourself or trust. The debug APK is unsigned for Play Store distribution but Android can install it locally.
